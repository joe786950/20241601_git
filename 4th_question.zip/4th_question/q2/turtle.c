#include <stdio.h>

void turtle() {

	printf("turtle\n");

	return;
}
