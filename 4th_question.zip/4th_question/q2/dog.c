#include <stdio.h>

void dog(){

	printf("dog\n");
	
	return;
}
