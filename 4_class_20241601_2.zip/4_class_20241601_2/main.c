#include <stdio.h>
#include "animal.h"

int main(){

	dog();
	blackcow();
	turtle();

	return 0;
}
